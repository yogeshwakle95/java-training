package com.example.demoweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemowebApplicationTests {

	@Test
	void contextLoads() {
	}

}
