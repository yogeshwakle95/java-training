package com.example.demoEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoExApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoExApplication.class, args);
	}

}
