package com.example.demo36;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo36Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo36Application.class, args);
	}

}
