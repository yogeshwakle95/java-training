package com.example.HtmlEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HtmlExApplicationTests {

	@Test
	void contextLoads() {
	}

}
