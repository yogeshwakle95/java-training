package com.example.demoItem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoItemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoItemApplication.class, args);
	}

}
