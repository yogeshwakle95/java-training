package com.example.demomovie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemomovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
